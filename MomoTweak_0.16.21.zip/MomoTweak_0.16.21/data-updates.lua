-- detect py mod
momoTweak.pycoal = false
momoTweak.pyfu = false
momoTweak.pyhigh = false
-- check for py mod
if data.raw.item["fawogae"] then momoTweak.pycoal = true end
if data.raw.item["molybdenum-ore"] then momoTweak.pyfu = true end
if data.raw.item["nanocrystaline-core"] then momoTweak.pyhigh = true end

-- apply py mod
if momoTweak.pycoal == true then 
	require("prototypes.pycom.py_data")
	require("prototypes.pycom.py")
end

if momoTweak.pyfu == true then
	require("prototypes.pycom.py_fu")
end

if momoTweak.pyhigh == true then 
	require("prototypes.pycom.pyhigh_ele")
	require("prototypes.pycom.pyhigh_ui")
end

require("prototypes.angel-tweak")
require("prototypes.assembler-upgrade")

require("prototypes.game-progress")

-- recipe tweak ------------------------------
require("prototypes.recipe.sandclay")
require("prototypes.recipe.bobs-electrolysis")
require("prototypes.recipe.logistic")
-- -------------------------------------------

-- recipe science ------------------------------
require("prototypes.sci.recipe")
require("prototypes.sci.sci30recipe")
require("prototypes.sci.sci30extreme")
-- ---------------------------------------------



if settings.startup["momo-harder-module"].value then
  require("prototypes.recipe.module")
  
end

require("prototypes.expensive")

require("prototypes.bobextended.bobextended-update")

require("prototypes.buff-solar")

require("prototypes.misc")


