TECHNOLOGY {
    type = "technology",
    name = "separation",
    icon = "__pycoalprocessing__/graphics/technology/separation.png",
    icon_size = 128,
    order = "c-a",
    prerequisites = {"coal-processing-1"},
    effects = {},
    unit = {
        count = 35,
        ingredients = {
            {"science-pack-1", 2}
        },
        time = 55
    }
}
