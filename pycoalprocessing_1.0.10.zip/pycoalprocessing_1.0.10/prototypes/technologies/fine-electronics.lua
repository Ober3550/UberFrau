TECHNOLOGY {
    type = "technology",
    name = "fine-electronics",
    icon = "__pycoalprocessing__/graphics/technology/fine-electronics.png",
    icon_size = 128,
    order = "c-a",
    prerequisites = {"coal-processing-2"},
    effects = {},
    unit = {
        count = 30,
        ingredients = {
            {"science-pack-1", 2},
            {"science-pack-2", 1}
        },
        time = 55
    }
}
