TECHNOLOGY {
    type = "technology",
    name = "methanol-processing-2",
    icon = "__pycoalprocessing__/graphics/technology/methanol-processing-2.png",
    icon_size = 128,
    order = "c-b",
    upgrade = true,
    effects = {},
    unit = {
        count = 150,
        ingredients = {
            {"science-pack-1", 1},
            {"science-pack-2", 1}
        },
        time = 35
    }
}
