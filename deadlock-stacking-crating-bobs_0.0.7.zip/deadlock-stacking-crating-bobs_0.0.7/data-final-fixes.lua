-- item name, tech level, has custom stack icon
local items = {
	{"solid-cement", 3, true},
	{"solid-glass-mixture", 3, true},
    {"angels-glass-plate", 2, false},
    {"ingot-unobtainium", 4, true},

    {"bronze-plate", 1, false},
	{"brass-plate", 2, false},

  	{"lithium", 2, false},

    {"quartz", 1, false},
    {"silicon", 2, false},
    {"ingot-silicon", 3, true},

    {"bauxite-ore", 2, false},
    {"aluminium-plate", 2, false},
    {"ingot-aluminium", 3, true},

    {"rutile-ore", 2, false},
    {"titanium-plate", 3, false},
    {"ingot-titanium", 4, true},

    {"thorium-ore", 2, false},
    {"phosphorus-ore", 1, false},

    {"cobalt-steel-plate", 2, false},
    {"gunmetal-plate", 2, false},
    {"invar-plate", 2, false},
    {"nitinol-plate", 3, false},

    {"copper-cable", 1, false},
    {"tinned-copper-cable", 1, false},
    {"gilded-copper-cable", 2, false},
    {"insulated-cable", 2, false},

    {"solder", 1, false},

    {"basic-electronic-components", 1, false},
    {"electronic-components", 1, false},
    {"intergrated-electronics", 2, false}, -- sic
    {"processing-electronics", 3, false},

    {"lithium", 2, false},

    {"stone-crushed", 1, false},
    {"glass", 1, false} -- bob's
}

for i = 1,6 do
    table.insert(items, {"angels-ore"..i, 1, false})
end

for i = 1,7 do
    table.insert(items, {"clowns-ore"..i, 1, false})
end

for _, i in ipairs({"tin", "lead"}) do
    table.insert(items, {i.."-ore", 1, false})
    table.insert(items, {i.."-plate", 1, false})
    table.insert(items, {"ingot-"..i, 2, true})
end

for _, i in ipairs({"iron", "copper", "steel"}) do
    table.insert(items, {"ingot-"..i, 2, true})
end

for _, i in ipairs({"manganese"}) do
    table.insert(items, {i.."-ore", 2, false})
    table.insert(items, {i.."-plate", 2, false})
    table.insert(items, {"ingot-"..i, 2, true})
end

for _, i in ipairs({"gold", "silver", "zinc", "nickel", "chrome"}) do
    table.insert(items, {i.."-ore", 2, false})
    table.insert(items, {i.."-plate", 2, false})
    table.insert(items, {"ingot-"..i, 3, true})
end

for _, i in ipairs({"cobalt", "platinum"}) do
    table.insert(items, {i.."-ore", 2, false})
    table.insert(items, {i.."-plate", 2, false})
    table.insert(items, {"ingot-"..i, 4, true})
end

for _, i in ipairs({"tungsten"}) do
    table.insert(items, {i.."-ore", 2, false})
    table.insert(items, {i.."-plate", 3, false})
    table.insert(items, {"ingot-"..i, 4, true})
end


if deadlock_stacking then
	for _, item in ipairs(items) do
		if data.raw.item[item[1]] then
            if item[3] then
    			deadlock_stacking.create(item[1], "__deadlock-stacking-crating-bobs__/graphics/"..item[1].."-stack.png", "deadlock-stacking-"..item[2])
            else
                deadlock_stacking.create(item[1], nil, "deadlock-stacking-"..item[2])
            end
		end
	end
end 

if deadlock_crating then
	for _, item in ipairs(items) do
		if data.raw.item[item[1]] then
			deadlock_crating.create(item[1], "deadlock-crating-"..math.min(item[2], 3))
		end
	end
end



