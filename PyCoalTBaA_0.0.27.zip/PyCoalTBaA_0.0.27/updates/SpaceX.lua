
if mods["SpaceMod"] then

	local recipes_list = {"tar-distilation",
							"bonemeal",
							"raw-borax",
							"ralesia",
							"rich-clay",
							"ground-sample01",
							"bio-sample01",
							"alien-sample01",
							"equipment-chassi",
							"lab-instrument",
							"lens",
							"boron-trioxide",
							"ralesia-seeds",
							"science-pack-2",
							"water-mineralized",
							"borax-washing",
							"tar-gasification",
							"coal-fawogae",
							"coke-coal",
							"stone-distilation",
							"log1",
							"log2",
							"log3",
							"log-wood",
							"concrete-richclay",
							"treated-wood",
							--"nichrome",
							"active-carbon",
							"zinc-chloride",
							"tailings-dust",
							"drill-head",
							"niobium-ore",
							"niobium-dust",
							"niobium-concentrate",
							"mukmoux-fat",
							"niobium-oxide",
							"niobium-plate",
							"log5",
							"rich-re",
							"eva-ree-dust",
							"organics-from-wood",
							"log4",
							"log6",
							"log-organics",
							"oleochemicals",
							--"richdust-seperation",
							"organic-solvent",
							"aromatic-organic",
							"petgas-methanol",
							"oleo-heavy",
							"making-chromium",
							"raw-wood-to-coal",
							"wood-to-coal",
							"coal-dust",
							"sand-brick",
							"oleochemicals-distilation",
							"calcium-carbide",
							"oleo-gasification",
							"lithium-peroxide",
							"nexelit-cartridge",
							"organics-processing",
							"sand-casting",
							"tar-oil",
							"air-pollution",
							"slacked-lime",
							"co2",
							"oleo-solidfuel",
							"glycerol-hydrogen",
							"coaldust-ash",
							"coalgas-combustion",
							"coalslurry-combustion",
							"syngas-combustion",
							"diborane-combustion",
							"methanol-combustion",
							"refsyngas-combustion",
							"acetylene-combustion",
							"olefin-combustion",
							"diesel-combustion",
							"gasoline-combustion",
							"supercritical-combustion",
							"ultrasupercritical-combustion",
							"niobium-powder",
							"crushing-iron",
							"crushing-copper",
							"stone-to-gravel",
							"gravel-to-sand",
							--safe items above
							"dirty-reaction",
							"coalgas-syngas",
							"sulfur-crudeoil",
							"sulfur-heavyoil",
							"sulfur-lightoil",
							"sulfur-petgas",
							"aromatics-to-lubricant",
							"explosive-glycerol",
							"extract-sulfur",
							--[["",
							"",
							"",
							"",
							"",
							"",
							"",
							"",
							"",
							"",
							"",
							"",
							"",
							"",
							"",
							"",
							"",
							"",
	]]--
	}
	
	if bobmods then
							
		table.insert(recipes_list, "crushing-bauxite")
		table.insert(recipes_list, "crushing-gold")
		table.insert(recipes_list, "crushing-lead")
		table.insert(recipes_list, "crushing-nickel")
		table.insert(recipes_list, "crushing-rutile")
		table.insert(recipes_list, "crushing-silver")
		table.insert(recipes_list, "crushing-tin")
		table.insert(recipes_list, "crushing-tungsten")
		table.insert(recipes_list, "crushing-zinc")
							
	end
	
	local factor = settings.startup["SpaceX"].value
--[[
	if mods["pyfusionenergy"] then
	table.insert(recipes_list, 'washing-crude')
	table.insert(recipes_list,'methyl-acrylate')
	end

	if mods["pyhightech"] then
	table.insert(recipes_list,'ree-concentrate3')
	table.insert(recipes_list,'rare-earth-beneficiation')
	table.insert(recipes_list,'pdms-graphene')
	table.insert(recipes_list,'plastic2')
	table.insert(recipes_list,'rayon')
	table.insert(recipes_list,'lithium-chloride')
	table.insert(recipes_list,'coal-briquette3')

	end
]]
	for i, recipe_name in ipairs(recipes_list) do
		
		if data.raw.recipe[recipe_name].results then
			local results = table.deepcopy(data.raw.recipe[recipe_name].results)
			
			for k, result in ipairs(results) do
				local reciperesultsname = table.deepcopy(data.raw.recipe[recipe_name].results[k].name)
				local reciperesultamount = (table.deepcopy(data.raw.recipe[recipe_name].results[k].amount) * factor)
				local result_type = table.deepcopy(data.raw.recipe[recipe_name].results[k].type)
					
				data.raw.recipe[recipe_name].results[k] = {type = result_type, name = reciperesultsname, amount = reciperesultamount}
				
			end
			
		else
			
				local reciperesultsname = table.deepcopy(data.raw.recipe[recipe_name].results[k].name)
				local reciperesultamount = (table.deepcopy(data.raw.recipe[recipe_name].results[k].amount) * factor)
				local result_type = table.deepcopy(data.raw.recipe[recipe_name].results[k].type)
				
				data.raw.recipe[recipe_name].results[k] = {type = result_type, name = reciperesultsname, amount = reciperesultamount}
		end
		
	end
	
end