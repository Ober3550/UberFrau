
if mods["angelspetrochem"] then

if mods["DeadlocksStackingForPyanadon"] then

if deadlock_stacking then
deadlock_stacking.create("solid-coke", nil, "deadlock-stacking-1")
deadlock_stacking.create("solid-limestone", nil, "deadlock-stacking-1")
deadlock_stacking.create("solid-lime", nil, "deadlock-stacking-1")
deadlock_stacking.create("solid-salt", nil, "deadlock-stacking-1")
deadlock_stacking.create("solid-sand", nil, "deadlock-stacking-1")
end

end

end