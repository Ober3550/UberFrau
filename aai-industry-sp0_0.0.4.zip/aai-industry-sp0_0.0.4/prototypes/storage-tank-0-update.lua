
table.insert(data.raw["technology"]["basic-fluid-handling"].effects, {type = "unlock-recipe",recipe = "storage-tank-0"})
table.insert(data.raw["recipe"]["storage-tank"].ingredients, {"storage-tank-0", 1})


