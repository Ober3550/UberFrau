require("prototypes.science-pack-0")
require("prototypes.storage-tank-0")
require("prototypes.coal-gas-from-fawogae")

require("functions")

table.insert(data.raw["lab"]["lab"].inputs, "science-pack-0")
