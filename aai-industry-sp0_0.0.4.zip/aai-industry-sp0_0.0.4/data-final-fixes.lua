
-- Thir parts adds all techs that are initial and does not contain green
--[[
for _,tech in pairs(data.raw.technology) do
	if tech.prerequisites == nil then
		local check = true
		for _, c in pairs(tech.unit.ingredients) do
			if c[1]=="science-pack-2" then 
				check = false
				break
			end
		end
		if check then industry.add_tech(tech.name) end
	end
end]]--

--this adds those you had
--industry.add_tech("electricity")
industry.add_tech("basic-fluid-handling")
industry.add_tech("basic-logistics")
industry.add_tech("omni-extraction-impure-base")

--this adds all before a later one, so you can just add a later tech and all prior gets automaticly added.
local ctn = true

while ctn do
	ctn = false
	for _,t in pairs(industry.techs) do
		local tc = data.raw.technology[t.name]
		if tc and tc.prerequisites ~= nil then
			for _, pre in pairs(tc.prerequisites) do
				if not industry.techs[pre] then
					ctn = true
					industry.add_tech(pre)
				end
			end
		end
	end
end

--this does the tech fixing.
for _, t in pairs(industry.techs) do
	industry.replace_science_pack(t.name)
end

--Adds science-pack-0 to all techs that comes after a teceh that already had science-pack-0.
--Does through by cycling through many times checking if it can constantly find one to add to and once it can't it stops.

local post_find = true
while post_find do
	post_find = false
	for _,tech in pairs(data.raw.technology) do
		if tech.prerequisites and #tech.prerequisites > 0 and (not string.find(tech.name,"module") or tech.name=="modules") then
			local techunits = {}
			for _,ing in pairs(tech.unit.ingredients) do
				techunits[ing[1]]={}
			end
			if not techunits["science-pack-0"] then
				for _,req in pairs(tech.prerequisites) do
					local requnits = {}
					if not data.raw.technology[req] then log("the prerequisite "..req.." does not exist") end
					for _,ing in pairs(data.raw.technology[req].unit.ingredients) do
						requnits[ing[1]]={}
					end
					if requnits["science-pack-0"] then
						log(tech.name)
						post_find = true
						industry.add_science_pack(tech.name)
						break
					end
				end
			end
		end
	end
end