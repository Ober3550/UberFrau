
local itemTable =
{
	--  ores
	{ "angels-ore1", 1},
	{ "angels-ore2", 1},
	{ "angels-ore3", 1},
	{ "angels-ore4", 1},
	{ "angels-ore5", 1},
	{ "angels-ore6", 1},
}

log(serpent.block(data.raw.item["thorium-ore"]))

if deadlock_stacking then
	for _, item in pairs(itemTable) do
		if data.raw.item[item[1]] then
			deadlock_stacking.create(item[1], "__stacking-addon__/graphics/"..item[1].."-stack.png", "deadlock-stacking-"..item[2])
		end
	end
end 

if deadlock_crating then
	for _, item in pairs(itemTable) do
		if data.raw.item[item[1]] then
			deadlock_crating.create(item[1], "deadlock-crating-"..item[2])
		end
	end
end
