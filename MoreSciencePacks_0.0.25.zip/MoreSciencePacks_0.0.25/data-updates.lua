if not morescience then morescience = {} end
if not morescience.tech then morescience.tech = {} end

require("prototypes.recipe.recipe-updates")
require("prototypes.recipe.recipe-integrations")
require("prototypes.technology.technology-updates")

--Set up science pack crafting-results based on config setting. Defaults will be used if the pack is disabled from technology. (prevents a recipe result = 0) While maintaining ability to disable a pack from being required for research.
--data.raw["recipe"]["more-science-pack-1"].result_count = settings.startup["MSP-pack1-result"].value * settings.startup["moresciencepack-multiplier"].value --old
for i=1,30 do
	if settings.startup["MSP-pack".. i .. "-result"].value > 0 then 
		data.raw["recipe"]["more-science-pack-"..i].result_count = settings.startup["MSP-pack"..i.."-result"].value * settings.startup["moresciencepack-multiplier"].value				
	end
end 


--Fix bob's inserter overhaul conflict --new notice: similar behaviour may also be required in dealing with changes AAI makes. 
if mods["boblogistics"] and settings.startup["bobmods-logistics-inserteroverhaul"].value == true then
	--if bob's logistics is installed, bob's library must be, therefore, we can use the existing function to replace the ingredient, and ensure the science pack can be crafted if the inserter-overhaul option is enabled. We may also need to check to see if some other mod has moved the fast inserter out of the basic logistics tech, and / or simply change the basic recipe to use the basic inserter regardless.. more testing needed.
	bobmods.lib.recipe.replace_ingredient("more-science-pack-4", "fast-inserter", "inserter")
	bobmods.lib.recipe.replace_ingredient("more-science-pack-20", "stack-inserter", "red-stack-inserter")

end

--ADD MSP science packs 1-30 to ALL LABS declared within data.raw.lab
--[[	We can go ahead and blacklist specific labs we don't want to add our science packs to such as creative-mode mod, which has it's own search&Add function or bob's module-lab for right now. 	
		This method will add all 30 science packs to EVERY lab that is not inthe blacklistLabs. This means, if a mod adds a lab type and a science pack type to that lab, and our integration function 
		edits technology that that mod adds: this method will ensure that the modded-lab receives our science packs as allowed-packs. 
]]
local blacklistLabs ={"creative-mode-fix_creative-lab", "lab-module"}

if mods["MomoTweak"] and mods["angelspetrochem"] and settings.startup["moresciencepack-no-lab-slots"].value == true and settings.startup["moresciencepack-GameProgressionFix"].value == true then 

--[[ IF all the above ascertions are true, prevent addition of msp packs as lab tools. packs will act as intermediates only in this configuration. 
This feature added for players who don't want the logistic hassle of inserting 37 science packs into labs, but are okay with very complex science crafting recipes. 
toggling game progression fix 
]]

else 
	for labX, labs in pairs(data.raw.lab) do
		if not morescience.tech.is_in_table(tostring(data.raw.lab[labX].name), blacklistLabs) then --enable blacklisting
			if settings.startup["moresciencepack-debugLogging"].value == true then log("debug Lab: " .. tostring(data.raw.lab[labX].name) .. " is not blacklisted. Adding MSP packs now...") end 
			--if a pack we add hasn't already been added to a lab by some other means or by another mod, such as creative-mode-mod, we'll go ahead and add the pack now.
			for i=1,30 do
				if not morescience.tech.is_in_table("more-science-pack-" .. i, data.raw.lab[labX].inputs) then 
					table.insert(data.raw.lab[labX].inputs, "more-science-pack-" .. i)				
					--ADD valid inputs rather then explicitly redefine inputs. this should prevent issues with labs having other custom-science packs removed due to explicit declaration.
				end 
			end
			
		else 
			if settings.startup["moresciencepack-debugLogging"].value == true then log("debug Lab: " .. tostring(data.raw.lab[labX].name) .. " exists in blacklist table. Skipping MSP-packs.") end 		
		end
	end
end