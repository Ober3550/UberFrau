
script.on_init(function()
	-- show warning if this game is not new-game
	local showerror = false
	
	--CONTROL.lua Cannot access GLOBAL!!!!
	--[[ -- cannot access global i.e: apparently control.lua can't access the list containing modnames
	local modlist ={"pycoalprocessing", "MoreScience"}
	--for each modName in modlist, if mod[modName] then showError = true
	for _, modName in pairs(modlist) do
		if mods[modName] then showerror = true	end 
	end 
	--]]
	if (game.tick > 10) and showerror then
		if not game.is_multiplayer() and game["players"] and #game["players"] == 1 then
			game.show_message_dialog{text={"gui-message.compat-warning-message"}}
		else
			game.print({"gui-message.compat-warning-message"})
		end
	end
end)
