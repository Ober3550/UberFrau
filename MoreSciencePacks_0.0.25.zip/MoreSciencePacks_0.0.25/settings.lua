--[[ wormmus settings-function example. 
require("settings-values")

local function msp_newModSetting_startup_string(name, order, default, allowedvalues)
    data:extend({
        {
            name = name,
            order = order,
            type = "string-setting",
            setting_type = "startup",
            default_value = default,
            allowed_values = allowedvalues
        }
    })
end

local function msp_newModSetting_startup_boolean(name, order, default, allowedvalues)
    data:extend({
        {
            name = name,
            order = order,
            type = "bool-setting",
            setting_type = "startup",
            default_value = default,
            allowed_values = allowedvalues
        }
    })
end

local function msp_newModSetting_startup_int(name, order, default, allowedvalues)
    data:extend({
        {
            name = name,
            order = order,
            type = "int-setting",
            setting_type = "startup",
            default_value = default,
            allowed_values = allowedvalues
        }
    })
end


wcm_newModSetting_startup_string("wcm-generation-map", "a-a", "Not Enabled", standard)


--]] --test


data:extend(
{
  {
    type = "bool-setting",
    name = "moresciencepack-IntegrationEngine",
    setting_type = "startup",
    default_value = true,
    per_user = false,
	order = "a-a-a"
  },
  {
    type = "bool-setting",
    name = "moresciencepack-EconomicsIntegration",
    setting_type = "startup",
    default_value = false,
    per_user = false,  
	order = "a-a-b"
  },  
  {
    type = "bool-setting",
    name = "moresciencepack-reset-ingredient-recipe-unlocks",
    setting_type = "startup",
    default_value = true,
    per_user = false,
	order = "a-a-c"
  },
  {
    type = "bool-setting",
    name = "moresciencepack-unlock-all-packs",
    setting_type = "startup",
    default_value = false,
    per_user = false,
	order = "a-a-d"
  },
  {
    type = "bool-setting",
    name = "moresciencepack-GameProgressionFix",
    setting_type = "startup",
    default_value = false,
    per_user = false,
	order = "a-a-e"
  },
  {
    type = "bool-setting",
    name = "moresciencepack-no-lab-slots",
    setting_type = "startup",
    default_value = false,
    per_user = false,
	order = "a-a-f"
  },  
  {
    type = "bool-setting",
    name = "moresciencepack-IncreasedModuleScienceCost",
    setting_type = "startup",
    default_value = false,
    per_user = false,
	order = "z-a-a"
  },  
  {
    type = "int-setting",
    name = "moresciencepack-ModuleScienceDifficulty",
    setting_type = "startup",
    default_value = 2,		
	maximum_value = 16,
	minimum_value = 2,
    per_user = false,
	order = "z-a-b"
  },
  {
    type = "bool-setting",
    name = "moresciencepack-debugLogging",
    setting_type = "startup",
    default_value = false,
    per_user = false,
	order = "a-b-d"
  },
  {
    type = "bool-setting",
    name = "moresciencepack-ErrorOnFail",
    setting_type = "startup",
    default_value = false,
    per_user = false,
	order = "a-b-e"
  },
  {
	type = "int-setting",
	name = "moresciencepack-multiplier",
	setting_type = "startup",
	default_value = 1,
	maximum_value = 100,
	minimum_value = 1,
	order = "b-a-a"
  },
  {
	type = "int-setting",
	name = "MSP-pack1-result",
	setting_type = "startup",
	default_value = 5,
	maximum_value = 1000,
	minimum_value = 0,
	order = "b-a-b"
  },
  {
	type = "int-setting",
	name = "MSP-pack2-result",
	setting_type = "startup",
	default_value = 8,
	maximum_value = 1000,
	minimum_value = 0,
	order = "b-a-c"
  },
  {
	type = "int-setting",
	name = "MSP-pack3-result",
	setting_type = "startup",
	default_value = 12,
	maximum_value = 1000,
	minimum_value = 0,
	order = "b-a-d"
  },
  {
	type = "int-setting",
	name = "MSP-pack4-result",
	setting_type = "startup",
	default_value = 7,
	maximum_value = 1000,
	minimum_value = 0,
	order = "b-a-e"
  },
  {
	type = "int-setting",
	name = "MSP-pack5-result",
	setting_type = "startup",
	default_value = 6,
	maximum_value = 1000,
	minimum_value = 0,
	order = "b-a-f"
  },
  {
	type = "int-setting",
	name = "MSP-pack6-result",
	setting_type = "startup",
	default_value = 8,
	maximum_value = 1000,
	minimum_value = 0,
	order = "b-a-g"
  },
  {
	type = "int-setting",
	name = "MSP-pack7-result",
	setting_type = "startup",
	default_value = 5,
	maximum_value = 1000,
	minimum_value = 0,
	order = "b-a-h"
  },
  {
	type = "int-setting",
	name = "MSP-pack8-result",
	setting_type = "startup",
	default_value = 4,
	maximum_value = 1000,
	minimum_value = 0,
	order = "b-a-i"
  },
  {
	type = "int-setting",
	name = "MSP-pack9-result",
	setting_type = "startup",
	default_value = 10,
	maximum_value = 1000,
	minimum_value = 0,
	order = "b-a-j"
  },
  {
	type = "int-setting",
	name = "MSP-pack10-result",
	setting_type = "startup",
	default_value = 10,
	maximum_value = 1000,
	minimum_value = 0,
	order = "b-a-k"
  },
  {
	type = "int-setting",
	name = "MSP-pack11-result",
	setting_type = "startup",
	default_value = 8,
	maximum_value = 1000,
	minimum_value = 0,
	order = "b-a-l"
  },
  {
	type = "int-setting",
	name = "MSP-pack12-result",
	setting_type = "startup",
	default_value = 32,
	maximum_value = 1000,
	minimum_value = 0,
	order = "b-a-m"
  },
  {
	type = "int-setting",
	name = "MSP-pack13-result",
	setting_type = "startup",
	default_value = 28,
	maximum_value = 1000,
	minimum_value = 0,
	order = "b-a-n"
  },
  {
	type = "int-setting",
	name = "MSP-pack14-result",
	setting_type = "startup",
	default_value = 20,
	maximum_value = 1000,
	minimum_value = 0,
	order = "b-a-o"
  },
  {
	type = "int-setting",
	name = "MSP-pack15-result",
	setting_type = "startup",
	default_value = 20,
	maximum_value = 1000,
	minimum_value = 0,
	order = "b-a-p"
  },
  {
	type = "int-setting",
	name = "MSP-pack16-result",
	setting_type = "startup",
	default_value = 20,
	maximum_value = 1000,
	minimum_value = 0,
	order = "b-a-q"
  },
  {
	type = "int-setting",
	name = "MSP-pack17-result",
	setting_type = "startup",
	default_value = 15,
	maximum_value = 1000,
	minimum_value = 0,
	order = "b-a-r"
  },
  {
	type = "int-setting",
	name = "MSP-pack18-result",
	setting_type = "startup",
	default_value = 60,
	maximum_value = 1000,
	minimum_value = 0,
	order = "b-a-s"
  },
  {
	type = "int-setting",
	name = "MSP-pack19-result",
	setting_type = "startup",
	default_value = 19,
	maximum_value = 1000,
	minimum_value = 0,
	order = "b-a-t"
  },
  {
	type = "int-setting",
	name = "MSP-pack20-result",
	setting_type = "startup",
	default_value = 50,
	maximum_value = 1000,
	minimum_value = 0,
	order = "b-a-u"
  },
  {
	type = "int-setting",
	name = "MSP-pack21-result",
	setting_type = "startup",
	default_value = 25,
	maximum_value = 1000,
	minimum_value = 0,
	order = "b-a-v"
  },
  {
	type = "int-setting",
	name = "MSP-pack22-result",
	setting_type = "startup",
	default_value = 32,
	maximum_value = 1000,
	minimum_value = 0,
	order = "b-a-w"
  },
  {
	type = "int-setting",
	name = "MSP-pack23-result",
	setting_type = "startup",
	default_value = 27,
	maximum_value = 1000,
	minimum_value = 0,
	order = "b-a-x"
  },
  {
	type = "int-setting",
	name = "MSP-pack24-result",
	setting_type = "startup",
	default_value = 5,
	maximum_value = 1000,
	minimum_value = 0,
	order = "b-a-y"
  },
  {
	type = "int-setting",
	name = "MSP-pack25-result",
	setting_type = "startup",
	default_value = 5,
	maximum_value = 1000,
	minimum_value = 0,
	order = "b-a-z"
  },
  {
	type = "int-setting",
	name = "MSP-pack26-result",
	setting_type = "startup",
	default_value = 5,
	maximum_value = 1000,
	minimum_value = 0,
	order = "b-b-a"
  },
  {
	type = "int-setting",
	name = "MSP-pack27-result",
	setting_type = "startup",
	default_value = 5,
	maximum_value = 1000,
	minimum_value = 0,
	order = "b-b-b"
  },
  {
	type = "int-setting",
	name = "MSP-pack28-result",
	setting_type = "startup",
	default_value = 13,
	maximum_value = 1000,
	minimum_value = 0,
	order = "b-b-c"
  },
  {
	type = "int-setting",
	name = "MSP-pack29-result",
	setting_type = "startup",
	default_value = 90,
	maximum_value = 1000,
	minimum_value = 0,
	order = "b-b-d"
  },
  {
	type = "int-setting",
	name = "MSP-pack30-result",
	setting_type = "startup",
	default_value = 35,
	maximum_value = 1000,
	minimum_value = 0,
	order = "b-b-e"
  }, 
  
  
}
)


