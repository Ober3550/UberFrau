if not morescience.tech then morescience.tech = {} end

--[[ Notes by author: usafphoenix, such as ideas, plans, issues detected, potential integration techniques, etc.

So my first inclination is to add a new function and use a tree-forming algorithm to determine which modded technologies have, by pre-requisite, no cyclic requirements for specific science types our mod adds (either due to locked recipe or technology alteration)---and use a method to add groups of science packs to entire lists or groups of technologies all at once. this would be, i think, by far, the simplest method, but there are BOUND to arise specific problems or situations where this causes games to be impossible to complete. 

Scenario 1) Player has the mod space chests installed. this mod forces logistic chests to require space science. , our mod requires the rocket silo to require all 30 science packs including the logistic-chest based packs. Result: game is impossible to complete unless the player removes Space-Chests mod (is basically just a recipe-edit mod).

Scenarios like the above present problems of the sort that are computationally easy to determine/detect/resolve, but in practice, is quite difficult to code correctly. 

In essence: the technology tree and all items must be traversed in lists: each technology must have it's pre-requisites checked, and ensure no situations arise where A requires B, but B isn't able to be gained until A is researched.


With a properly formed function, it would be relatively easy to use it as a basis to say "okay, these technologies have a pre-requisite-tree that dictates/tells us that science packs 1-7 have been unlocked". We then load the recipes to verify all the ingredients are available, then one final check before determining which packs to add to that technology. we can also assume that if a pre-requisite technology has science packs 1-5 in their ingredient list, that any technology that requires the previous technology can ALSO have science packs 1-5 as well (would speed things up quite a bit)

]]

--local tmpArray = {"0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","1","1"}
--morescience.tech.add_science_pack_array({"warehouse-logistics-research"},{"0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","1","1"}, 1) --initial test


--unable to reference within data-final-fixes.
local blacklist =
{
	--"military-2",
	--"advanced-electronics",
	--"advanced-electronics-2",
	--"advanced-material-processing-2",
}
--conditional mod & config dependent setting application, use from template below: 
--if mods["boblogistics"] and settings.startup["bobmods-logistics-inserteroverhaul"].value == true then

--Technology Pre-requisite fixes use: morescience.tech.remove_prerequisite(technology, prerequisite)
if mods["aai-industry"] then
morescience.tech.remove_prerequisite("turrets", "military") --fix technology override that breaks progression if AAI Industry is added. 
end

--OMNIMATTER
if mods["omnimatter"] then --and settings.startup["msp-omnimatter-integration"].value == true then

--unable to locate process/prototype for omnimatter technology generation to determine local-names as required for science-pack adding/processing. Seems to be done dynamically, which is likely to cause problems, so while the two mods remain compatible....integration is unlikely for the time being....

--technologies are made within omnilib iniside recipe-generation.lua  starting on line 1079
--dynamic allocation and naming based upon config settings means integration+compatability assurance is almost impossible at this time. A PROPER scanning function needs to be devised that can enable dynamic integration with such a unique mod as omnimatter.

--[[
list of omnimatter techs pulled from integration function debugging method 
  90.304 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-omnic-acid-hydrolyzation-1 retrieved by MSP.
  90.304 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-omnic-acid-hydrolyzation-2 retrieved by MSP.
  90.304 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-omnic-acid-hydrolyzation-3 retrieved by MSP.
  90.304 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-omnic-acid-hydrolyzation-4 retrieved by MSP.
  90.304 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-omnic-acid-hydrolyzation-5 retrieved by MSP.
  90.344 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-pseudoliquid-amorphous-crystal-1 retrieved by MSP.
  90.345 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-pseudoliquid-amorphous-crystal-2 retrieved by MSP.
  90.346 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-pseudoliquid-amorphous-crystal-3 retrieved by MSP.
  90.347 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-pseudoliquid-amorphous-crystal-4 retrieved by MSP.
  90.348 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-pseudoliquid-amorphous-crystal-5 retrieved by MSP.
  90.349 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-omnic-water-omnitraction-1 retrieved by MSP.
  90.350 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-omnic-water-omnitraction-2 retrieved by MSP.
  90.350 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-omnic-water-omnitraction-3 retrieved by MSP.
  90.350 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-omnic-water-omnitraction-4 retrieved by MSP.
  90.350 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-omnic-water-omnitraction-5 retrieved by MSP.
  90.350 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-omnic-water-omnitraction-6 retrieved by MSP.
  90.350 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-omnic-water-omnitraction-7 retrieved by MSP.
  90.350 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-omnic-water-omnitraction-8 retrieved by MSP.
  90.351 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-omnic-water-omnitraction-9 retrieved by MSP.
  90.351 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-omnic-water-omnitraction-10 retrieved by MSP.
  90.351 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-water-viscous-mud-omnitraction-1 retrieved by MSP.
  90.351 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-water-viscous-mud-omnitraction-2 retrieved by MSP.
  90.352 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-water-viscous-mud-omnitraction-3 retrieved by MSP.
  90.352 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-water-viscous-mud-omnitraction-4 retrieved by MSP.
  90.352 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-water-viscous-mud-omnitraction-5 retrieved by MSP.
  90.352 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-water-viscous-mud-omnitraction-6 retrieved by MSP.
  90.352 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-water-viscous-mud-omnitraction-7 retrieved by MSP.
  90.352 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-water-viscous-mud-omnitraction-8 retrieved by MSP.
  90.353 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-water-viscous-mud-omnitraction-9 retrieved by MSP.
  90.353 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-water-viscous-mud-omnitraction-10 retrieved by MSP.
  90.353 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-water-yellow-waste-omnitraction-1 retrieved by MSP.
  90.353 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-water-yellow-waste-omnitraction-2 retrieved by MSP.
  90.354 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-water-yellow-waste-omnitraction-3 retrieved by MSP.
  90.354 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-water-yellow-waste-omnitraction-4 retrieved by MSP.
  90.354 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-water-yellow-waste-omnitraction-5 retrieved by MSP.
  90.354 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-water-yellow-waste-omnitraction-6 retrieved by MSP.
  90.354 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-water-yellow-waste-omnitraction-7 retrieved by MSP.
  90.354 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-water-yellow-waste-omnitraction-8 retrieved by MSP.
  90.355 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-water-yellow-waste-omnitraction-9 retrieved by MSP.
  90.355 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-water-yellow-waste-omnitraction-10 retrieved by MSP.
  90.355 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-water-red-waste-omnitraction-1 retrieved by MSP.
  90.356 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-water-red-waste-omnitraction-2 retrieved by MSP.
  90.356 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-water-red-waste-omnitraction-3 retrieved by MSP.
  90.356 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-water-red-waste-omnitraction-4 retrieved by MSP.
  90.356 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-water-red-waste-omnitraction-5 retrieved by MSP.
  90.356 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-water-red-waste-omnitraction-6 retrieved by MSP.
  90.356 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-water-red-waste-omnitraction-7 retrieved by MSP.
  90.356 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-water-red-waste-omnitraction-8 retrieved by MSP.
  90.357 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-water-red-waste-omnitraction-9 retrieved by MSP.
  90.357 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-water-red-waste-omnitraction-10 retrieved by MSP.
  90.357 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-water-green-waste-omnitraction-1 retrieved by MSP.
  90.358 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-water-green-waste-omnitraction-2 retrieved by MSP.
  90.358 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-water-green-waste-omnitraction-3 retrieved by MSP.
  90.358 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-water-green-waste-omnitraction-4 retrieved by MSP.
  90.358 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-water-green-waste-omnitraction-5 retrieved by MSP.
  90.358 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-water-green-waste-omnitraction-6 retrieved by MSP.
  90.358 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-water-green-waste-omnitraction-7 retrieved by MSP.
  90.358 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-water-green-waste-omnitraction-8 retrieved by MSP.
  90.359 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-water-green-waste-omnitraction-9 retrieved by MSP.
  90.359 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-water-green-waste-omnitraction-10 retrieved by MSP.
  90.359 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-water-greenyellow-waste-omnitraction-1 retrieved by MSP.
  90.360 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-water-greenyellow-waste-omnitraction-2 retrieved by MSP.
  90.360 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-water-greenyellow-waste-omnitraction-3 retrieved by MSP.
  90.360 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-water-greenyellow-waste-omnitraction-4 retrieved by MSP.
  90.360 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-water-greenyellow-waste-omnitraction-5 retrieved by MSP.
  90.360 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-water-greenyellow-waste-omnitraction-6 retrieved by MSP.
  90.360 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-water-greenyellow-waste-omnitraction-7 retrieved by MSP.
  90.360 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-water-greenyellow-waste-omnitraction-8 retrieved by MSP.
  90.361 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-water-greenyellow-waste-omnitraction-9 retrieved by MSP.
  90.361 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-water-greenyellow-waste-omnitraction-10 retrieved by MSP.
  90.361 Script @__MoreSciencePacks__/functions.lua:213: Technology omniwaste retrieved by MSP.

  91.453 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitractor-electric-1 retrieved by MSP.
  91.453 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitractor-electric-2 retrieved by MSP.
  91.455 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitractor-electric-3 retrieved by MSP.
  91.458 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitractor-electric-4 retrieved by MSP.
  91.463 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitractor-electric-5 retrieved by MSP.
  91.468 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-coal-1 retrieved by MSP.
  91.468 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-coal-2 retrieved by MSP.
  91.468 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-coal-3 retrieved by MSP.
  91.468 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-coal-4 retrieved by MSP.
  91.469 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-coal-5 retrieved by MSP.
  91.469 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-coal-6 retrieved by MSP.
  91.469 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-angels-ore5-1 retrieved by MSP.
  91.470 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-angels-ore5-2 retrieved by MSP.
  91.470 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-angels-ore5-3 retrieved by MSP.
  91.470 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-angels-ore5-4 retrieved by MSP.
  91.470 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-angels-ore5-5 retrieved by MSP.
  91.470 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-angels-ore5-6 retrieved by MSP.
  91.471 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-angels-ore6-1 retrieved by MSP.
  91.471 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-angels-ore6-2 retrieved by MSP.
  91.471 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-angels-ore6-3 retrieved by MSP.
  91.471 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-angels-ore6-4 retrieved by MSP.
  91.472 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-angels-ore6-5 retrieved by MSP.
  91.472 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-angels-ore6-6 retrieved by MSP.
  91.472 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-y-res1-1 retrieved by MSP.
  91.472 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-y-res1-2 retrieved by MSP.
  91.473 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-y-res1-3 retrieved by MSP.
  91.473 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-y-res1-4 retrieved by MSP.
  91.473 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-y-res1-5 retrieved by MSP.
  91.473 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-y-res1-6 retrieved by MSP.
  91.474 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-clowns-ore2-1 retrieved by MSP.
  91.474 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-clowns-ore2-2 retrieved by MSP.
  91.474 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-clowns-ore2-3 retrieved by MSP.
  91.474 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-clowns-ore2-4 retrieved by MSP.
  91.475 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-clowns-ore2-5 retrieved by MSP.
  91.475 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-clowns-ore2-6 retrieved by MSP.
  91.475 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-clowns-ore3-1 retrieved by MSP.
  91.475 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-clowns-ore3-2 retrieved by MSP.
  91.476 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-clowns-ore3-3 retrieved by MSP.
  91.476 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-clowns-ore3-4 retrieved by MSP.
  91.476 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-clowns-ore3-5 retrieved by MSP.
  91.476 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-clowns-ore3-6 retrieved by MSP.
  91.477 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-clowns-ore4-1 retrieved by MSP.
  91.477 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-clowns-ore4-2 retrieved by MSP.
  91.477 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-clowns-ore4-3 retrieved by MSP.
  91.477 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-clowns-ore4-4 retrieved by MSP.
  91.477 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-clowns-ore4-5 retrieved by MSP.
  91.478 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-clowns-ore4-6 retrieved by MSP.
  91.478 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-clowns-ore5-1 retrieved by MSP.
  91.478 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-clowns-ore5-2 retrieved by MSP.
  91.478 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-clowns-ore5-3 retrieved by MSP.
  91.479 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-clowns-ore5-4 retrieved by MSP.
  91.479 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-clowns-ore5-5 retrieved by MSP.
  91.479 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-clowns-ore5-6 retrieved by MSP.
  91.479 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-clowns-resource1-1 retrieved by MSP.
  91.480 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-clowns-resource1-2 retrieved by MSP.
  91.480 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-clowns-resource1-3 retrieved by MSP.
  91.480 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-clowns-resource1-4 retrieved by MSP.
  91.480 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-clowns-resource1-5 retrieved by MSP.
  91.481 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-clowns-resource1-6 retrieved by MSP.
  91.481 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-clowns-resource2-1 retrieved by MSP.
  91.481 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-clowns-resource2-2 retrieved by MSP.
  91.481 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-clowns-resource2-3 retrieved by MSP.
  91.482 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-clowns-resource2-4 retrieved by MSP.
  91.482 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-clowns-resource2-5 retrieved by MSP.
  91.482 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-clowns-resource2-6 retrieved by MSP.
  91.482 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-stone-1 retrieved by MSP.
  91.483 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-stone-2 retrieved by MSP.
  91.483 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-stone-3 retrieved by MSP.
  91.483 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-stone-4 retrieved by MSP.
  91.484 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-stone-5 retrieved by MSP.
  91.484 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-stone-6 retrieved by MSP.
  91.485 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-angels-ore2-1 retrieved by MSP.
  91.485 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-angels-ore2-2 retrieved by MSP.
  91.485 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-angels-ore2-3 retrieved by MSP.
  91.485 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-angels-ore2-4 retrieved by MSP.
  91.486 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-angels-ore2-5 retrieved by MSP.
  91.486 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-angels-ore2-6 retrieved by MSP.
  91.486 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-angels-ore4-1 retrieved by MSP.
  91.487 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-angels-ore4-2 retrieved by MSP.
  91.487 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-angels-ore4-3 retrieved by MSP.
  91.487 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-angels-ore4-4 retrieved by MSP.
  91.488 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-angels-ore4-5 retrieved by MSP.
  91.488 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-angels-ore4-6 retrieved by MSP.
  91.488 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-tenemut-1 retrieved by MSP.
  91.489 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-tenemut-2 retrieved by MSP.
  91.489 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-tenemut-3 retrieved by MSP.
  91.489 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-tenemut-4 retrieved by MSP.
  91.490 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-tenemut-5 retrieved by MSP.
  91.490 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-tenemut-6 retrieved by MSP.
  91.490 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-y-res2-1 retrieved by MSP.
  91.491 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-y-res2-2 retrieved by MSP.
  91.491 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-y-res2-3 retrieved by MSP.
  91.491 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-y-res2-4 retrieved by MSP.
  91.492 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-y-res2-5 retrieved by MSP.
  91.492 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-y-res2-6 retrieved by MSP.
  91.492 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-clowns-ore1-1 retrieved by MSP.
  91.493 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-clowns-ore1-2 retrieved by MSP.
  91.493 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-clowns-ore1-3 retrieved by MSP.
  91.493 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-clowns-ore1-4 retrieved by MSP.
  91.493 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-clowns-ore1-5 retrieved by MSP.
  91.494 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-clowns-ore1-6 retrieved by MSP.
  91.494 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-clowns-ore6-1 retrieved by MSP.
  91.495 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-clowns-ore6-2 retrieved by MSP.
  91.495 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-clowns-ore6-3 retrieved by MSP.
  91.495 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-clowns-ore6-4 retrieved by MSP.
  91.495 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-clowns-ore6-5 retrieved by MSP.
  91.496 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-clowns-ore6-6 retrieved by MSP.
  91.496 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-clowns-ore7-1 retrieved by MSP.
  91.496 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-clowns-ore7-2 retrieved by MSP.
  91.497 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-clowns-ore7-3 retrieved by MSP.
  91.497 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-clowns-ore7-4 retrieved by MSP.
  91.497 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-clowns-ore7-5 retrieved by MSP.
  91.498 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-clowns-ore7-6 retrieved by MSP.
  91.498 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-angels-ore1-1 retrieved by MSP.
  91.498 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-angels-ore1-2 retrieved by MSP.
  91.498 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-angels-ore1-3 retrieved by MSP.
  91.498 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-angels-ore1-4 retrieved by MSP.
  91.499 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-angels-ore1-5 retrieved by MSP.
  91.499 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-angels-ore1-6 retrieved by MSP.
  91.499 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-angels-ore3-1 retrieved by MSP.
  91.499 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-angels-ore3-2 retrieved by MSP.
  91.499 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-angels-ore3-3 retrieved by MSP.
  91.499 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-angels-ore3-4 retrieved by MSP.
  91.500 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-angels-ore3-5 retrieved by MSP.
  91.500 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-extraction-angels-ore3-6 retrieved by MSP.
  91.500 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-coal-1 retrieved by MSP.
  91.500 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-coal-2 retrieved by MSP.
  91.500 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-coal-3 retrieved by MSP.
  91.500 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-angels-ore5-1 retrieved by MSP.
  91.501 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-angels-ore5-2 retrieved by MSP.
  91.501 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-angels-ore5-3 retrieved by MSP.
  91.501 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-angels-ore6-1 retrieved by MSP.
  91.501 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-angels-ore6-2 retrieved by MSP.
  91.501 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-angels-ore6-3 retrieved by MSP.
  91.501 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-y-res1-1 retrieved by MSP.
  91.501 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-y-res1-2 retrieved by MSP.
  91.502 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-y-res1-3 retrieved by MSP.
  91.502 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-clowns-ore2-1 retrieved by MSP.
  91.502 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-clowns-ore2-2 retrieved by MSP.
  91.502 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-clowns-ore2-3 retrieved by MSP.
  91.502 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-clowns-ore3-1 retrieved by MSP.
  91.502 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-clowns-ore3-2 retrieved by MSP.
  91.502 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-clowns-ore3-3 retrieved by MSP.
  91.503 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-clowns-ore4-1 retrieved by MSP.
  91.503 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-clowns-ore4-2 retrieved by MSP.
  91.503 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-clowns-ore4-3 retrieved by MSP.
  91.503 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-clowns-ore5-1 retrieved by MSP.
  91.503 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-clowns-ore5-2 retrieved by MSP.
  91.503 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-clowns-ore5-3 retrieved by MSP.
  91.503 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-clowns-resource1-1 retrieved by MSP.
  91.504 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-clowns-resource1-2 retrieved by MSP.
  91.504 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-clowns-resource1-3 retrieved by MSP.
  91.504 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-clowns-resource2-1 retrieved by MSP.
  91.504 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-clowns-resource2-2 retrieved by MSP.
  91.504 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-clowns-resource2-3 retrieved by MSP.
  91.504 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-stone-1 retrieved by MSP.
  91.504 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-stone-2 retrieved by MSP.
  91.505 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-stone-3 retrieved by MSP.
  91.505 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-angels-ore2-1 retrieved by MSP.
  91.505 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-angels-ore2-2 retrieved by MSP.
  91.505 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-angels-ore2-3 retrieved by MSP.
  91.505 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-angels-ore4-1 retrieved by MSP.
  91.506 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-angels-ore4-2 retrieved by MSP.
  91.506 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-angels-ore4-3 retrieved by MSP.
  91.506 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-tenemut-1 retrieved by MSP.
  91.506 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-tenemut-2 retrieved by MSP.
  91.506 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-tenemut-3 retrieved by MSP.
  91.507 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-y-res2-1 retrieved by MSP.
  91.507 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-y-res2-2 retrieved by MSP.
  91.507 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-y-res2-3 retrieved by MSP.
  91.507 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-clowns-ore1-1 retrieved by MSP.
  91.507 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-clowns-ore1-2 retrieved by MSP.
  91.508 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-clowns-ore1-3 retrieved by MSP.
  91.508 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-clowns-ore6-1 retrieved by MSP.
  91.508 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-clowns-ore6-2 retrieved by MSP.
  91.508 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-clowns-ore6-3 retrieved by MSP.
  91.509 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-clowns-ore7-1 retrieved by MSP.
  91.509 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-clowns-ore7-2 retrieved by MSP.
  91.509 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-clowns-ore7-3 retrieved by MSP.
  91.509 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-base-impure-extraction-1 retrieved by MSP.
  91.509 Script @__MoreSciencePacks__/functions.lua:232: There is no prerequisities listed under omnitech-base-impure-extraction-1 for MSP integration
  91.509 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-angels-ore1-1 retrieved by MSP.
  91.509 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-angels-ore1-2 retrieved by MSP.
  91.509 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-angels-ore1-3 retrieved by MSP.
  91.509 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-angels-ore3-1 retrieved by MSP.
  91.510 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-angels-ore3-2 retrieved by MSP.
  91.510 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-focused-extraction-angels-ore3-3 retrieved by MSP.
  91.510 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-water-omnitraction-1 retrieved by MSP.
  91.510 Script @__MoreSciencePacks__/functions.lua:232: There is no prerequisities listed under omnitech-water-omnitraction-1 for MSP integration
  91.510 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-water-omnitraction-2 retrieved by MSP.
  91.510 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-water-omnitraction-3 retrieved by MSP.
  91.510 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-water-omnitraction-4 retrieved by MSP.
  91.510 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-solvation-omniston-1 retrieved by MSP.
  91.510 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-solvation-omniston-2 retrieved by MSP.
  91.510 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-solvation-omniston-3 retrieved by MSP.
  91.510 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-solvation-omniston-4 retrieved by MSP.
  91.511 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-solvation-omniston-5 retrieved by MSP.
  91.511 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-omnisolvent-omnisludge-1 retrieved by MSP.
  91.511 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-omnisolvent-omnisludge-2 retrieved by MSP.
  91.511 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-omnisolvent-omnisludge-3 retrieved by MSP.
  91.511 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-omnisolvent-omnisludge-4 retrieved by MSP.
  91.512 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-omnisolvent-omnisludge-5 retrieved by MSP.
  91.512 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-distillation-thermal-water-1 retrieved by MSP.
  91.512 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-distillation-thermal-water-2 retrieved by MSP.
  91.513 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-distillation-thermal-water-3 retrieved by MSP.
  91.513 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-distillation-thermal-water-4 retrieved by MSP.
  91.513 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-distillation-thermal-water-5 retrieved by MSP.
  91.514 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-distillation-gas-natural-1-1 retrieved by MSP.
  91.514 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-distillation-gas-natural-1-2 retrieved by MSP.
  91.514 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-distillation-gas-natural-1-3 retrieved by MSP.
  91.514 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-distillation-gas-natural-1-4 retrieved by MSP.
  91.514 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-distillation-gas-natural-1-5 retrieved by MSP.
  91.515 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-distillation-liquid-multi-phase-oil-1 retrieved by MSP.
  91.515 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-distillation-liquid-multi-phase-oil-2 retrieved by MSP.
  91.515 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-distillation-liquid-multi-phase-oil-3 retrieved by MSP.
  91.515 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-distillation-liquid-multi-phase-oil-4 retrieved by MSP.
  91.515 Script @__MoreSciencePacks__/functions.lua:213: Technology omnitech-distillation-liquid-multi-phase-oil-5 retrieved by MSP.







)

]]


end

--ANGELS

--angels mods now have some integration due to tie-ins with the vanilla tech tree, but explicit declarations have not been determined (not sure what levels/technologies to set for which science packs)
