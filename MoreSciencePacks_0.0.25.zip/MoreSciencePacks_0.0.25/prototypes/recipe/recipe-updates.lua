--space chests set space science as a requirement for some logistic chests (current exception being the passive provider, at my suggestion, thus, we'll set up conversion recipes for the science packs until a better method/recipe idea is given for this particular case.)
if mods["Space-Chests"]	then
	data:extend(
	{
	  {
		type = "recipe",
		name = "more-science-pack-24",
		energy_required = 5, enabled = false,
		ingredients =
		{
		  {"logistic-chest-passive-provider", 2},
		},
		result = "more-science-pack-24"
		,result_count = 5,
	  },
	  {
		type = "recipe",
		name = "more-science-pack-25",
		energy_required = 5, enabled = false,
		ingredients =
		{
		  {"more-science-pack-24", 5},
		},
		result = "more-science-pack-25"
		,result_count = 5,
	  },
	  
	  {
		type = "recipe",
		name = "more-science-pack-26",
		energy_required = 5, enabled = false,
		ingredients =
		{
		  {"more-science-pack-25", 5}
		},
		result = "more-science-pack-26"
		,result_count = 5,
	  },
	  
	  {
		type = "recipe",
		name = "more-science-pack-27",
		energy_required = 5, enabled = false,
		ingredients =
		{
		  {"more-science-pack-26", 5},
		},
		result = "more-science-pack-27"
		,result_count = 5,
	  },
	}
	)
end


if mods["omnilib"]	and data.raw.item["offshore-pump-source"] then --fix omni renaming vanilla items.
	data:extend(
	{
	  {
		type = "recipe",
		name = "more-science-pack-5",
		energy_required = 5, enabled = false,
		ingredients =
		{
		  {"offshore-pump-source", 1},
		  {"boiler", 1}
		},
		result = "more-science-pack-5"
		,result_count = 3,
	  },
	}
	)
end
 
if mods["bobmodules"] and settings.startup["moresciencepack-IncreasedModuleScienceCost"].value == true then		-- and data.raw.item[]

	local tier = settings.startup["moresciencepack-ModuleScienceDifficulty"].value
	--basic tier productivity and 
	if tier > 2 then 	
		if tier < 9 then 
			data:extend(
			{
				{
				type = "recipe",
				name = "more-science-pack-18",
				energy_required = 5, enabled = false,
				ingredients =
				{
				  {"speed-module-"..tostring(tier), 1},
				  {"productivity-module-"..tostring(tier), 1}
				},
				result = "more-science-pack-18"
				,result_count = 60,
			},
			})
		end
		
		if tier > 8 then 
			tier = tier - 8  --reallign integer/tier for bob's raw-modules
		
			if settings.startup["bobmods-modules-enablerawspeedmodules"].value == true and settings.startup["bobmods-modules-enablerawproductivitymodules"].value == true then 
				data:extend(
				{
				  {
					type = "recipe",
					name = "more-science-pack-18",
					energy_required = 5, enabled = false,
					ingredients =
					{
					  {"raw-speed-module-"..tier, 1},
					  {"raw-productivity-module-"..tier, 1}
					},
					result = "more-science-pack-18"
					,result_count = 60,
				  },
				})	
			else -- raw modules have not been enabled. incraese cost internally
				data:extend(
					{
					  {
						type = "recipe",
						name = "more-science-pack-18",
						energy_required = 5, enabled = false,
						ingredients =
						{
						  {"speed-module-"..tier, tier+2},
						  {"productivity-module-"..tier, tier+2}
						},
						result = "more-science-pack-18"
						,result_count = 60,
					  },
					})				
			end
		end
	end	
else if not mods["bobmodules"] and settings.startup["moresciencepack-IncreasedModuleScienceCost"].value == true then
			data:extend(
				{
				  {
					type = "recipe",
					name = "more-science-pack-18",
					energy_required = 5, enabled = false,
					ingredients =
					{
					  {"speed-module-2", settings.startup["moresciencepack-IncreasedModuleScienceCost"].value},
					  {"productivity-module-2", settings.startup["moresciencepack-IncreasedModuleScienceCost"].value}
					},
					result = "more-science-pack-18"
					,result_count = 60,
				  },
				})	

	end
end






