data.raw.recipe["science-pack-1"].icon = "__base__/graphics/icons/science-pack-1.png"
data.raw.recipe["science-pack-2"].icon = "__base__/graphics/icons/science-pack-2.png"
data.raw.recipe["science-pack-3"].icon = "__base__/graphics/icons/science-pack-3.png"
data.raw.recipe["military-science-pack"].icon = "__base__/graphics/icons/military-science-pack.png"
data.raw.recipe["production-science-pack"].icon = "__base__/graphics/icons/production-science-pack.png"
data.raw.recipe["high-tech-science-pack"].icon = "__base__/graphics/icons/high-tech-science-pack.png"

data.raw.recipe["science-pack-1"].icon_size = 32
data.raw.recipe["science-pack-2"].icon_size = 32
data.raw.recipe["science-pack-3"].icon_size = 32
data.raw.recipe["military-science-pack"].icon_size = 32
data.raw.recipe["production-science-pack"].icon_size = 32
data.raw.recipe["high-tech-science-pack"].icon_size = 32

data.raw.tool["science-pack-1"].icon = "__base__/graphics/icons/science-pack-1.png"
data.raw.tool["science-pack-2"].icon = "__base__/graphics/icons/science-pack-2.png"
data.raw.tool["science-pack-3"].icon = "__base__/graphics/icons/science-pack-3.png"
data.raw.tool["military-science-pack"].icon = "__base__/graphics/icons/military-science-pack.png"
data.raw.tool["production-science-pack"].icon = "__base__/graphics/icons/production-science-pack.png"
data.raw.tool["high-tech-science-pack"].icon = "__base__/graphics/icons/high-tech-science-pack.png"