if not morescience then morescience = {} end
if not morescience.tech then morescience.tech = {} end

require("functions")

--START DYNAMIC RECIPE FORMATION
require("prototypes.recipe.recipe-dynamic")

if data.raw.technology["omnitech-more-science-pack-18-1"] then --fix pack 18 not getting caught in integration pass. 

	morescience.tech.add_science_pack_range({"omnitech-more-science-pack-18-1"}, 1, 12, 1)
	morescience.tech.add_science_pack_range({"omnitech-more-science-pack-18-1"}, 17, 17, 1)

end



--now we scan through the technology tree and add packs. 
if not settings.startup["moresciencepack-GameProgressionFix"].value == true then 

	require("prototypes.technology.technology-vanilla")
	require("prototypes.technology.technology-modded")

	--RUN INTEGRATION ENGINE x2
	if settings.startup["moresciencepack-IntegrationEngine"].value == true then morescience.tech.integrate() end
	if settings.startup["moresciencepack-IntegrationEngine"].value == true then morescience.tech.integrate() end
	--duplicated the line that runs the integration engine (same function will now run twice). Necessary due to the way it traverses the technology tree; certain later-tier techs were being skipped if they were scanned before their prerequisites had been edited (thus resulting in higher-tier technologies sometimes requiring less science types than those that came before them). A second run of the function should catch those remaining technologies and add appropriate levels of science to those that slip through on the first run. This does not enable further integration with mods that have their technology completely isolated from vanilla (no prerequisites to the base game technologies).

end
 


--ascertion feature doesn't work; appears to cause more problems than it fixes.
if  settings.startup["moresciencepack-reset-ingredient-recipe-unlocks"].value == true then
	morescience.tech.reset_recipe_unlock("", "burner-inserter")
	morescience.tech.reset_recipe_unlock("", "burner-mining-drill")
	morescience.tech.reset_recipe_unlock("", "light-armor")
	morescience.tech.reset_recipe_unlock("", "pistol")
	morescience.tech.reset_recipe_unlock("optics", "small-lamp")
	morescience.tech.reset_recipe_unlock("logistics", "fast-inserter")
	morescience.tech.reset_recipe_unlock("automation", "long-handed-inserter")
	morescience.tech.reset_recipe_unlock("", "stone-furnace")
	--morescience.tech.reset_recipe_unlock("", "pipe") --literally does nothing.
	morescience.tech.reset_recipe_unlock("", "boiler")
	morescience.tech.reset_recipe_unlock("", "offshore-pump")
	morescience.tech.reset_recipe_unlock("advanced-material-processing", "steel-furnace")
	morescience.tech.reset_recipe_unlock("circuit-network", "red-wire")
	morescience.tech.reset_recipe_unlock("circuit-network", "green-wire")
	morescience.tech.reset_recipe_unlock("circuit-network", "constant-combinator")
	morescience.tech.reset_recipe_unlock("", "iron-stick")
		if not mods["bobelectronics"] then morescience.tech.reset_recipe_unlock("", "electronic-circuit") end		
	morescience.tech.reset_recipe_unlock("solar-energy", "solar-panel")
	morescience.tech.reset_recipe_unlock("electric-energy-accumulators", "accumulator")
	morescience.tech.reset_recipe_unlock("battery", "battery")
	morescience.tech.reset_recipe_unlock("railway", "rail")
	morescience.tech.reset_recipe_unlock("rail-signals", "rail-signal")
	morescience.tech.reset_recipe_unlock("rail-signals", "rail-chain-signal")
	morescience.tech.reset_recipe_unlock("construction-robotics","construction-robot")
	morescience.tech.reset_recipe_unlock("battery-equipment", "battery-equipment")
	morescience.tech.reset_recipe_unlock("flamethrower", "flamethrower")
	morescience.tech.reset_recipe_unlock("flamethrower", "flamethrower-ammo")
end








