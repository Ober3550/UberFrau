--MSP constants
morescience.levels = settings.startup["moresciencepack-levels-MSP"].value -- number of techs/levels of efficiency per item/[pack type]
morescience.omni_maximum = settings.startup["moresciencepack-omni-maximum"].value --maximum [limited final yield amount] for efficiency-levels-per-pack
