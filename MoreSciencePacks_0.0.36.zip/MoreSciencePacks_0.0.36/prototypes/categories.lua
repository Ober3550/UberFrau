data:extend(
{
  {
    type = "item-group",
    name = "MoreSciencePacks",
    order = "z",
    inventory_order = "z",
    icon = "__MoreSciencePacks__/graphics/efficiency-generic.png",
	icon_size = 128,
  },
}
)