data:extend({
    {
        type = "bool-setting",
        name = "deadlock-stacking-hide-unstacking",
		order = "a",
        setting_type = "startup",
        default_value = false
    }
})