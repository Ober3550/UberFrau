data:extend(
{
  {
    type = "recipe-category",
    name = "momo-sci-recipe"
  }
})

local sci_cat = "crafting"
if  data.raw["assembling-machine"]["angels-chemical-plant"] and settings.startup["momo-fix-angels-chemistry-machine"].value then
  sci_cat = "momo-sci-recipe"
end
local ele = momoTweak.ele

momoTweak.createRecipe(sci_cat, {{"red-sci", 5}},
  {
    {"science-pack-1", 2},
    {ele.circuit[1], 3}
  }, 5, "logistics")

momoTweak.createRecipe("crafting", {{"building-pack", 1}},
  {
    {"iron-gear-wheel", 5},
    {"stone-furnace", 1}
  }, 6, true)
momoTweak.createRecipe("crafting", {{"building-pack", 1}},
  {
    {"burner-mining-drill", 1}
  }, 2, true, "-burner-")
  
local belt = "transport-belt"
momoTweak.createRecipe(sci_cat, {{"movement-pack", 2}},
  {
    {belt, 2},
    {"inserter", 1},
    {"copper-plate", 3}
  }, 3, "logistics")

local tech_sci_3 = momoTweak.get_tech_of_recipe("science-pack-3")
momoTweak.createRecipe(sci_cat, {{"green-sci", 4}},
  {
    {"red-sci", 3},
    {"science-pack-2", 2},
    {ele.unit[2], 2},
    {"silicon-wafer", 7},
  }, 12, tech_sci_3)
  

momoTweak.createRecipe(sci_cat, {{"bronze-pack", 1}},
  {
    {"bronze-alloy", 4},
    {"lead-plate", 4},
	{"battery", 2},
  }, 8, "mixing-steel-furnace")

local tech_sci_mil = momoTweak.get_tech_of_recipe("military-science-pack")
momoTweak.createRecipe(sci_cat, {{"pre-dark-sci", 2}},
  {
    {"science-pack-2", 1},
    {"piercing-rounds-magazine", 2},
    {"grenade", 2},
    {"dark-chip", 3}
  }, 10, tech_sci_mil)
momoTweak.createRecipe(sci_cat, {{"dark-chip", 4}},
  {
    {"solder", 4},
    {ele.comp[1], 5},
    {ele.unit[1], 3},
    {"movement-pack", 1}
  }, 5, tech_sci_mil)
  
local tech_sci_pro = momoTweak.get_tech_of_recipe("production-science-pack")
momoTweak.createRecipe(sci_cat, {{"pre-cyan-sci", 4}}, {
  {"science-pack-3", 1},
  {"green-sci", 6},
  {"red-sci", 4},
  {ele.circuit[2], 4},
  {"solder", 6}
}, 12, tech_sci_pro)

momoTweak.createRecipe(sci_cat, {{"cpy", 4}}, {
  
  {"insulated-cable", 6},
  {"solder", 6},
  {ele.board[2], 4},
  {"robot-brain-logistic", 2}
  
}, 10, tech_sci_pro)

momoTweak.createRecipe(sci_cat, {{"product-sci", 1}}, {
  {"solar-panel-2", 1},
  {"bob-area-mining-drill-1", 1},
  {"electric-furnace", 1},
  {"pre-cyan-sci", 3}
}, 14, tech_sci_pro)

momoTweak.createRecipe(sci_cat, {{"cyan-sci", 3}}, {
  {"green-sci", 6},
  {"science-pack-3", 1},
  {"pre-cyan-sci", 4},
  {"bronze-pack", 2},
  
}, 14, tech_sci_3)

momoTweak.createRecipe(sci_cat, {{"logistic-express", 1}}, 
  data.raw.recipe["logistic-science-pack"].ingredients, 14, "logistics-3"
)
local tech_high = momoTweak.get_tech_of_recipe("high-tech-science-pack")
momoTweak.createRecipe(sci_cat, {{"pre-high-sci", 1}}, 
  {
    {"cyan-sci", 5},
    {ele.unit[3], 1},
    {ele.board[3], 4},
    {"solder", 6},
    {"cpy", 1},
    {ele.comp[5], 3}
  }, 14, tech_high)
  
momoTweak.createRecipe(sci_cat, {{"py-nxag-matrix", 2}},
  {
    {"titanium-plate", 6},
    {"cobalt-steel-alloy", 4},
    {"building-pack", 7},
    {"electric-engine-unit", 1},
    {"lithium-ion-battery", 6},
    {"green-sci", 7}
    
  }, 14, tech_high)
  
momoTweak.createRecipe(sci_cat, {{"py-superconductor", 4}},
  {
    {"plastic-bar", 7},
    {"silver-plate", 12},
    {"bronze-pack", 8},
    {"heat-shield-tile", 5},
    {"red-sci", 4}
    
  }, 14, tech_high)

  
 -- Science 1 ----------------------------------------------------------------------------
if momoTweak.pycoal == false then
	momoTweak.set_amount_ingredient("science-pack-1", {"copper-plate", 2})
end
------------------------------------------------------------------------------------------

 -- Science 2 ----------------------------------------------------------------------------
bobmods.lib.recipe.remove_ingredient("science-pack-2", "transport-belt")
bobmods.lib.recipe.remove_ingredient("science-pack-2", "basic-transport-belt")
bobmods.lib.recipe.remove_ingredient("science-pack-2", "inserter")

if momoTweak.pycoal then
	momoTweak.newsciItem("py-green")
	local items = data.raw.recipe["science-pack-2"].ingredients
	table.insert(items, {"building-pack", 2})
	momoTweak.createRecipe(sci_cat, {{"py-green", 1}},  items, 5, true)
	momoTweak.set_all_ingredient("science-pack-2", {})
	
	bobmods.lib.recipe.add_ingredient("science-pack-2", {"py-green", 1})
else
	bobmods.lib.recipe.add_ingredient("science-pack-2", {"building-pack", 2})
end

bobmods.lib.recipe.add_ingredient("science-pack-2", {"red-sci", 3})
bobmods.lib.recipe.add_ingredient("science-pack-2", {"movement-pack", 3})
------------------------------------------------------------------------------------------

------------------------------------------------------------------------------------------
bobmods.lib.recipe.remove_ingredient("military-science-pack", "grenade")
bobmods.lib.recipe.remove_ingredient("military-science-pack", "piercing-rounds-magazine")
bobmods.lib.recipe.add_ingredient("military-science-pack", {"pre-dark-sci", 1})
bobmods.lib.recipe.add_ingredient("military-science-pack", {"red-sci", 6})
------------------------------------------------------------------------------------------

-- science-pack-3 ----------------------------------------------------------------------

bobmods.lib.recipe.remove_ingredient("science-pack-3", "battery")
bobmods.lib.recipe.remove_ingredient("science-pack-3", "advanced-circuit")
bobmods.lib.recipe.remove_ingredient("science-pack-3", "bronze-alloy")
if momoTweak.pycoal then
	momoTweak.newsciItem("py-cyan")
	local items = data.raw.recipe["science-pack-3"].ingredients
	table.insert(items, {"dark-chip", 8})
	momoTweak.createRecipe(sci_cat, {{"py-cyan", 1}},  items, 12, true)
	momoTweak.set_all_ingredient("science-pack-3", {})
	
	bobmods.lib.recipe.add_ingredient("science-pack-3", {"py-cyan", 1})
else
	bobmods.lib.recipe.add_ingredient("science-pack-3", {"dark-chip", 8})
end

bobmods.lib.recipe.add_ingredient("science-pack-3", {"green-sci", 6})
bobmods.lib.recipe.add_ingredient("science-pack-3", {"bronze-pack", 3})

------------------------------------------------------------------------------------------

------------------------------------------------------------------------------------------
bobmods.lib.recipe.remove_ingredient("production-science-pack", "electric-mining-drill")
bobmods.lib.recipe.remove_ingredient("production-science-pack", "electric-furnace")

if momoTweak.pyfu then
	momoTweak.newsciItem("py-pro")
	local items = data.raw.recipe["production-science-pack"].ingredients
	table.insert(items, {"cpy", 4})
	momoTweak.createRecipe(sci_cat, {{"py-pro", 1}},  items, 16, true)
	momoTweak.set_all_ingredient("production-science-pack", {})
	
	bobmods.lib.recipe.add_ingredient("production-science-pack", {"py-pro", 1})
else
	bobmods.lib.recipe.add_ingredient("production-science-pack", {"cpy", 4})
end

bobmods.lib.recipe.add_ingredient("production-science-pack", {"product-sci", 1})
bobmods.lib.recipe.add_ingredient("production-science-pack", {"cyan-sci", 2})

------------------------------------------------------------------------------------------

data.raw.recipe["logistic-science-pack"].ingredients = {
  {"logistic-express", 1},
  {"cpy", 5},
  {"pre-cyan-sci", 4},
  {"green-sci", 6},
  {"building-pack", 5},
}

------------------------------------------------------------------------------------------
bobmods.lib.recipe.remove_ingredient("high-tech-science-pack", "silicon-nitride")
bobmods.lib.recipe.remove_ingredient("high-tech-science-pack", "electric-engine-unit")
bobmods.lib.recipe.remove_ingredient("high-tech-science-pack", "lithium-ion-battery")
bobmods.lib.recipe.remove_ingredient("high-tech-science-pack", "processing-unit")

if momoTweak.pyhigh then
	momoTweak.newsciItem("py-gold")
	local items = data.raw.recipe["high-tech-science-pack"].ingredients
	momoTweak.createRecipe(sci_cat, {{"py-gold", 1}},  items, 16, true)
	momoTweak.set_all_ingredient("high-tech-science-pack", {})
	
	bobmods.lib.recipe.add_ingredient("high-tech-science-pack", {"py-gold", 1})
end

bobmods.lib.recipe.add_ingredient("high-tech-science-pack", {"pre-high-sci", 1})
bobmods.lib.recipe.add_ingredient("high-tech-science-pack", {"py-nxag-matrix", 2})
bobmods.lib.recipe.add_ingredient("high-tech-science-pack", {"py-superconductor", 5})
bobmods.lib.recipe.add_ingredient("high-tech-science-pack", {"solar-panel-equipment-3", 2})
------------------------------------------------------------------------------------------



