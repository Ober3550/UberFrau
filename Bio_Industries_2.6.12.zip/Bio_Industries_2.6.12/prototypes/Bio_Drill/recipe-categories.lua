data:extend(
{
	
	{
		type = "recipe-category",
		name = "bi-drill"
	},
}
)