data:extend({

--- Damage for Dart Turret Ammo

  {
    type = "damage-type",
    name = "bob-pierce"
  },
  
})
