
data:extend(
{
  {
    type = "ammo-category",
    name = "Bio_Cannon_Ammo",
    order = "1"
  },
}
)
