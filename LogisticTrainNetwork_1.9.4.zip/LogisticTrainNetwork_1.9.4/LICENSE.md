Copyright (c) 2018 Optera

This software is provided without warranty and the author/license holder cannot be held liable.

-	Private Use - I am not imposing any limitations on private use, if you want to modify my work, or create your own using parts of mine, you are free to do so as long as this altered or derived work does not become accessible to the public.
-	No Commercial Use - You are not allowed to make money off my work.
-	No Modification - Although I can't stop you from looking at my code, you are not allowed to distribute anything altered, or derived from my code without expressed permission first.
-	Distribution - You are allowed to redistribute my mods as is. This includes being repackaged as part of a mod pack.
- Contributions - Contributions are welcome, however due to legal reasons you have to agree to transfer ownership of said contributions to me.

Exceptions to the no modification rule include:
- Minor bug fixes/tweak for compatibility reasons, such as altering the dependencies line in info.json to force a load order in a modpack.
- Config - Any config.lua file may be edited and freely redistributed by itself.

Any further modifications, such as changing values of entities/recipes in my mods should be done externally in another mod.
If you would like to use any extracts from this mod in your own, please talk to me about it first.