TECHNOLOGY {
    type = "technology",
    name = "graphene",
    icon = "__pyhightech__/graphics/technology/graphene.png",
    icon_size = 128,
    order = "c-a",
    prerequisites = {"advanced-electronics"},
    effects = {},
    unit = {
        count = 55,
        ingredients = {
            {"science-pack-1", 3},
            {"science-pack-2", 1},
			{"science-pack-3", 2},
        },
        time = 45
    }
}
