TECHNOLOGY {
    type = "technology",
    name = "nucleo",
    icon = "__pyhightech__/graphics/technology/nucleosyntesis.png",
    icon_size = 128,
    order = "c-a",
    prerequisites = {"basic-electronics"},
    effects = {},
    unit = {
        count = 200,
        ingredients = {
            {"science-pack-1", 3},
            {"science-pack-2", 2},
        },
        time = 55
    }
}
