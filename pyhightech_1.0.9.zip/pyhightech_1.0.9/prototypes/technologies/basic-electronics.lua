TECHNOLOGY {
    type = "technology",
    name = "basic-electronics",
    icon = "__pyhightech__/graphics/technology/basic-electronics.png",
    icon_size = 128,
    order = "c-a",
    prerequisites = {"coal-processing-2"},
    effects = {},
    unit = {
        count = 55,
        ingredients = {
            {"science-pack-1", 1},
            {"science-pack-2", 1}
        },
        time = 45
    }
}
