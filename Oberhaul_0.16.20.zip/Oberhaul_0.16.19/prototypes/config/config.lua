data.raw.item["beacon"].stack_size = 100

--Misc Changes
data.raw.recipe["red-wire"].ingredients = {{"electronic-circuit", 1}}
data.raw.recipe["green-wire"].ingredients = {{"electronic-circuit", 1}}
data.raw.recipe["bob-rubber"].hidden = true
--Only hand craft resin
data:extend(
{
{
type = "recipe-category",
    name = "crafting-handonly"
  },

})

data.raw.recipe["bob-resin-wood"].category = "crafting-handonly"

data.raw.recipe["bob-resin-wood"].result_count = 1
data.raw.recipe["bob-resin-wood"].ingredients = {{"raw-wood",1}}
data.raw.recipe["bob-resin-wood"].energy_required = 0.25
table.insert(data.raw.player.player.crafting_categories, "crafting-handonly")

data.raw.recipe["lithium-ion-battery"].normal.energy_required = 5
data.raw.recipe["silver-zinc-battery"].normal.energy_required = 5

if mods["aai-industry"] then
    if not util then
    util = {}    
    end
    function util.allow_productivity(recipe_name)
        for _, prototype in pairs(data.raw["module"]) do
            if  prototype.limitation and string.find(prototype.name, "productivity", 1, true) then
                table.insert(prototype.limitation, recipe_name)
            end
        end
    end
    util.allow_productivity("motor")
    util.allow_productivity("electric-motor")
    data.raw.item["vehicle-fuel"].stack_size = 50
    data.raw.recipe["flying-robot-frame"].normal.ingredients = 
    {
          {"electric-engine-unit", 2},
          {"battery", 2},
          {"electronic-circuit", 2},
          {"steel-plate", 4},
    }
end
if mods.OmegaDrill then
--Omega Drill
data.raw.technology["omega-drill"].prerequisites = { "bob-logistics-4", "bob-drills-4"}
data.raw.technology["omega-drill"].unit = {
      count = 300,
      ingredients = {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
	{"science-pack-3", 1},
	{"production-science-pack", 1},
	{"high-tech-science-pack", 1}
      },
      time = 30
}
data.raw["mining-drill"]["omega-drill"].module_specification = 
{
      module_slots = 10,
      module_info_icon_shift = {0, 0.5},
      module_info_multi_row_initial_height_modifier = -0.3
}
data.raw.recipe["omega-drill"].ingredients = 
{
    {"electric-engine-unit",25},
    {"turbo-transport-belt",10},
    {"bob-mining-drill-4",25},
    {"advanced-processing-unit",25},
    {"tungsten-gear-wheel",20},
    {"nitinol-bearing",10}

}
end

data.raw.item["nuclear-fuel"].stack_size = 2

if mods.bobpower then
data.raw.recipe["heat-exchanger"].ingredients = {
    {"boiler-4",1},
    {"titanium-pipe",20},
    {"copper-plate",100},
    {"steel-plate",100},
}
data.raw.recipe["steam-turbine"].ingredients = {
    {"steam-engine-4",1},
    {"titanium-pipe",20},
    {"copper-plate",50},
    {"iron-gear-wheel",100},
}
end

if mods.bobplates then
--Fix the darn items left in inv from crafting bearings
data.raw.recipe["steel-bearing-ball"].result_count = 8
--data.raw.recipe["cobalt-steel-bearing-ball"].result_count = 8
data.raw.recipe["titanium-bearing-ball"].result_count = 8
data.raw.recipe["nitinol-bearing-ball"].result_count = 8
data.raw.recipe["ceramic-bearing-ball"].result_count = 8

bobmods.lib.recipe.remove_ingredient("rocket-silo","processing-unit")
bobmods.lib.recipe.add_ingredient("rocket-silo",{"advanced-processing-unit",400})

bobmods.lib.recipe.remove_ingredient("rocket-silo","concrete")
bobmods.lib.recipe.add_ingredient("rocket-silo",{"refined-concrete",1000})
end

if mods.CompactPower then
bobmods.lib.recipe.remove_ingredient("cp-solar-panel-mk2","copper-cable")
bobmods.lib.recipe.remove_ingredient("cp-solar-panel-mk3","copper-cable")
bobmods.lib.recipe.remove_ingredient("cp-solar-panel-mk4","copper-cable")
bobmods.lib.recipe.remove_ingredient("cp-solar-panel-mk5","copper-cable")

bobmods.lib.recipe.add_ingredient("cp-solar-panel-mk2",{"glass",4})
bobmods.lib.recipe.add_ingredient("cp-solar-panel-mk2",{"silver-plate",4})

bobmods.lib.recipe.add_ingredient("cp-solar-panel-mk3",{"silicon-wafer",32})
bobmods.lib.recipe.add_ingredient("cp-solar-panel-mk3",{"gold-plate",8})
bobmods.lib.recipe.add_ingredient("cp-solar-panel-mk3",{"titanium-plate",8})

bobmods.lib.recipe.add_ingredient("cp-solar-panel-mk4",{"tungsten-plate",8})

bobmods.lib.recipe.remove_ingredient("cp-accumulator-mk2","copper-cable")
bobmods.lib.recipe.remove_ingredient("cp-accumulator-mk3","copper-cable")
bobmods.lib.recipe.remove_ingredient("cp-accumulator-mk4","copper-cable")
bobmods.lib.recipe.remove_ingredient("cp-accumulator-mk5","copper-cable")

bobmods.lib.recipe.add_ingredient("cp-accumulator-mk2",{"lithium-ion-battery",4})
bobmods.lib.recipe.add_ingredient("cp-accumulator-mk2",{"steel-plate",3})

bobmods.lib.recipe.add_ingredient("cp-accumulator-mk3",{"silver-zinc-battery",4})
bobmods.lib.recipe.add_ingredient("cp-accumulator-mk3",{"titanium-plate",4})

bobmods.lib.recipe.add_ingredient("cp-accumulator-mk4",{"tungsten-plate",8})
end
