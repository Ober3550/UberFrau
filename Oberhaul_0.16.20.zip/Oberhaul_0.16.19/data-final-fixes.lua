require('prototypes.technology.technology')
require('prototypes.config.config')
require('prototypes.config.trains')
require('prototypes.config.logistics')
require('prototypes.config.angelsrefining')
require('prototypes.config.angelsconcrete')
require('prototypes.config.gems')
require('prototypes.config.electrolyser')

if not mods.CircuitProcessing then
    require('prototypes.config.assemblers')
    require('prototypes.config.modules')
end
if settings.startup["angels-ores-only"].value then
    require('prototypes.config.angelsoverride')
end