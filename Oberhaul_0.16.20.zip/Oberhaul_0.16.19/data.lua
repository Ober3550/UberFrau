if not settings.startup["angels-ores-only"].value then
    angelsmods.refining.disable_ore_override = true;
end