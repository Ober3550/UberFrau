data:extend({
   {
      type = "bool-setting",
      name = "modules-use-circuits",
      setting_type = "startup",
      default_value = true,
   },
   {
      type = "bool-setting",
      name = "angels-ores-only",
      setting_type = "startup",
      default_value = false,
   },
})