-- get bob electronic back to where it belong
local targetsubgroup = "bob-electronic-components"
local ordercount = 1;
local function goback (Item) 
	if data.raw.item[Item] then
		data.raw.item[Item].subgroup = targetsubgroup
		data.raw.item[Item].order = "a"..ordercount
		ordercount = ordercount + 1
	end
end
data:extend({
	{
		type = "item-subgroup",
		name = "bob-electronic-pyhigh-comp-a",
		group = data.raw["item-subgroup"]["bob-electronic-boards"].group,
		order = data.raw["item-subgroup"]["bob-electronic-boards"].order .. "a"
	},
	{
		type = "item-subgroup",
		name = "bob-electronic-pyhigh-comp-b",
		group = data.raw["item-subgroup"]["bob-electronic-boards"].group,
		order = data.raw["item-subgroup"]["bob-electronic-boards"].order .. "b"
	},
	{
		type = "item-subgroup",
		name = "bob-electronic-pyhigh-comp-c",
		group = data.raw["item-subgroup"]["bob-electronic-boards"].group,
		order = data.raw["item-subgroup"]["bob-electronic-boards"].order .. "c"
	},
		{
		type = "item-subgroup",
		name = "bob-electronic-pyhigh-comp-d",
		group = data.raw["item-subgroup"]["bob-electronic-boards"].group,
		order = data.raw["item-subgroup"]["bob-electronic-boards"].order .. "d"
	},
		{
		type = "item-subgroup",
		name = "bob-electronic-pyhigh",
		group = data.raw["item-subgroup"]["bob-electronic-boards"].group,
		order = data.raw["item-subgroup"]["bob-electronic-boards"].order .. "zz"
	}
})

for	i, name in pairs(momoTweak.ele.comp) do goback(name) end


targetsubgroup = "bob-electronic-boards"
goback("formica")
goback("phenolicboard")
goback("fiberglass")
for	i, name in pairs(momoTweak.ele.board) do goback(name) end
for	i, name in pairs(momoTweak.ele.circuit) do goback(name) end
for	i, name in pairs(momoTweak.ele.unit) do goback(name) end

targetsubgroup = "bob-electronic-pyhigh"
goback("pcb1")
goback("pcb2")
goback("pcb3")
goback("pcb3-2")
goback("pcb4")
goback("kondo-substrate")
goback("kondo-core")
goback("kondo-processor")

targetsubgroup = "bob-electronic-pyhigh-comp-a"
goback("capacitor1")
goback("capacitor2")
goback("capacitor-core")
goback("capacitor-termination")
goback("capacitor3")
goback("supercapacitor")
goback("supercapacitor-core")
goback("supercapacitor-shell")

targetsubgroup = "bob-electronic-pyhigh-comp-b"
goback("resistor1")
goback("resistor2")
goback("resistor3")
goback("paradiamatic-resistor")
goback("diode")
goback("diode3")
goback("diode-core")
goback("csle-diode")

targetsubgroup = "bob-electronic-pyhigh-comp-c"
goback("inductor1")
goback("inductor2")
goback("high-flux-core")
goback("inductor3")
goback("fault-current-inductor")
goback("superconductor")
goback("sc-substrate")
goback("superconductor-servomechanims")


targetsubgroup = "bob-electronic-pyhigh-comp-d"

goback("transistor")
goback("microchip")
goback("processor-core")
goback("processor")
goback("intelligent-unit")
goback("valve")
goback("pi-josephson-junction")
goback("var-josephson-junction")



