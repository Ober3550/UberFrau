
-- change recipe for first assembler
data.raw["assembling-machine"]["assembling-machine-1"].ingredient_count = 3

bobmods.lib.recipe.add_ingredient("assembling-machine-1", {momoTweak.burner, 1})
momoTweak.set_amount_ingredient("assembling-machine-1", {"iron-gear-wheel", 2})
momoTweak.set_amount_ingredient("assembling-machine-1", {"basic-circuit-board", 3})