-- check for angel's ref
if data.raw.technology["ore-crushing"] then
  data.raw.technology["ore-crushing"].unit = {
      count = 5,
      ingredients = {
        {"science-pack-1", 1},
      },
      time = 15
    }
end

if data.raw.item["solid-sand"] then data.raw.item["solid-sand"].stack_size = 1000 end
if data.raw.item["solid-clay"] then data.raw.item["solid-clay"].stack_size = 500 end
if data.raw.item["solid-mud"] then data.raw.item["solid-mud"].stack_size = 500 end

if momoTweak.pycoal and data.raw.item["glass"] then
	data.raw.item["glass"].stack_size = 300 
end