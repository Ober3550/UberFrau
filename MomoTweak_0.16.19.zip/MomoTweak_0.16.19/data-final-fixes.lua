

--momoTweak.find_recipe_from_result("raw-wood")
--momoTweak.find_recipe_from_ingredient("fiberboard")

-- disable chemical plant from angel's petro
local cat_override = "bob-distillery"
if settings.startup["momo-30-sci-extreme"].value then
	cat_override = "momo-sci-recipe"
end


if data.raw.technology["angels-advanced-chemistry-4"] and settings.startup["momo-fix-angels-chemistry-machine"].value then 
	bobmods.lib.tech.remove_recipe_unlock("electrolysis-1", "bob-distillery")
	if settings.startup["momo-30-sci-extreme"].value == false then
		bobmods.lib.tech.remove_recipe_unlock("basic-chemistry-2", "angels-chemical-plant")
		bobmods.lib.tech.remove_recipe_unlock("angels-advanced-chemistry-2", "angels-chemical-plant-2")
		bobmods.lib.tech.remove_recipe_unlock("angels-advanced-chemistry-3", "angels-chemical-plant-3")
		bobmods.lib.tech.remove_recipe_unlock("angels-advanced-chemistry-4", "angels-chemical-plant-4")
	end
  
	  -- put it on distillery cause there no recipe for it
	  local chemBase = momoTweak.deepcopy(data.raw["assembling-machine"]["chemical-plant"].crafting_categories)
	  local dirty = false
	  for i, angel in pairs( data.raw["assembling-machine"]["angels-chemical-plant"].crafting_categories ) do
		local have = false
		for k, base in pairs( data.raw["assembling-machine"]["chemical-plant"].crafting_categories ) do
			if (angel == base) then have = true end
		end
		
		if have == false then
			log ("MTKL => Angel chem not overlap = " .. angel)
			table.insert(chemBase, angel)
			dirty = true
		end
	  end
	  
	  if not dirty then log("MTKL no standalone cat for angels chem") end
	  
	  data.raw["assembling-machine"]["angels-chemical-plant"].ingredient_count = 5
	  data.raw["assembling-machine"]["angels-chemical-plant"].crafting_categories = {cat_override}
	  data.raw["assembling-machine"]["angels-chemical-plant-2"].ingredient_count = 5
	  data.raw["assembling-machine"]["angels-chemical-plant-2"].crafting_categories = {cat_override}
	  data.raw["assembling-machine"]["angels-chemical-plant-2"].ingredient_count = 6
	  data.raw["assembling-machine"]["angels-chemical-plant-3"].crafting_categories = {cat_override}
	  data.raw["assembling-machine"]["angels-chemical-plant-3"].ingredient_count = 10
	  data.raw["assembling-machine"]["angels-chemical-plant-4"].crafting_categories = {cat_override}
	  data.raw["assembling-machine"]["angels-chemical-plant-4"].ingredient_count = 10
	  
	  data.raw["assembling-machine"]["chemical-plant"].crafting_categories = chemBase
	  data.raw["assembling-machine"]["chemical-plant-2"].crafting_categories = chemBase
	  data.raw["assembling-machine"]["chemical-plant-3"].crafting_categories = chemBase
	  data.raw["assembling-machine"]["chemical-plant-4"].crafting_categories = chemBase
end

if momoTweak.pycoal == true then
	require ("prototypes.pycom.py_final")
	if mods["angelsbioprocessing"] then
		require("prototypes.pycom.py_angelbio")
	end
end
if momoTweak.pyhigh == true then
	require ("prototypes.pycom.pyhigh_final")
	if settings.startup["momo-harder-module"].value then
		require("prototypes.pycom.pyhigh_module")
	end
	if settings.startup["momo-enable-progress-electronics"].value then
		require("prototypes.pycom.pyhigh_ele_final")
	end
end


require("prototypes.sci.sci30result-preset")

function fixWaterBore()
	if settings.startup["bobmods-plates-groundwater"].value == false then
		data.raw.technology["water-bore-1"].enabled = false
		data.raw.technology["water-bore-2"].enabled = false
		data.raw.technology["water-bore-3"].enabled = false
		data.raw.technology["water-bore-4"].enabled = false
	end
end

-- try to fix standalone group
function fixGem()  
  local gemGroup = data.raw["item-subgroup"]["bob-gems-ore"].group;
  if gemGroup == "bob-resource-products" then
    data.raw["item-subgroup"][data.raw.recipe["polishing-compound"].subgroup].group = gemGroup
  end
end
function fixEQ()
  local sub = data.raw.item["gun-turret"].subgroup
  local eqGroup = data.raw["item-subgroup"][sub].group
  local target = data.raw.armor["light-armor"].subgroup or data.raw.armor["heavy-armor"].subgroup
  data.raw["item-subgroup"][target].group = eqGroup
end

if pcall(fixGem) then
  log("MTKL fix gem group complete~")
else
  log("MTKL can't fix gem group!!!!!!!!!")
end

if pcall(fixEQ) then
  log("MTKL fix EQ group complete~")
else
  log("MTKL can't fix EQ group!!!!!!!!!")
end

if pcall(fixWaterBore) then
	log("MTKL fix  water bore tech complete~")
else
	error("remove water bore")
end
